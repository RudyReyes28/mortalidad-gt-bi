
Modelo de Machine Learning - Regresion Logistica

Problema:
Clasificacion de exceso de mortalidad en Guatemala por departamento y mes.

Fuente:
dw.fact_defunciones_gt

Grano del modelo:
departamento - anio - mes

Variable objetivo:
exceso_mortalidad

Definicion:
La variable objetivo toma valor 1 cuando las muertes observadas superan en al menos 15%
el promedio historico pre-COVID 2018-2019 para el mismo departamento y mes.
En caso contrario, toma valor 0.

Modelo:
Regresion Logistica entrenada en Databricks usando scikit-learn.

Umbral de decision del modelo:
0.4

Metricas finales:
Accuracy: 0.7164502164502164
Precision: 0.5916030534351145
Recall: 0.8659217877094972
F1-score: 0.7029478458049887

Matriz de confusion:
[[176 107]
 [ 24 155]]

Archivos incluidos:
- modelo_logreg_defunciones_gt.joblib
- feature_columns.joblib
- config_modelo.json
- metricas_modelo.json
- matriz_confusion.csv
- comparacion_umbrales.csv
- coeficientes_modelo.csv
- README_modelo.txt

Seguridad:
No se incluyen credenciales ni secrets dentro de este archivo.
La conexion al DW se realizo mediante dbutils.secrets.get().
