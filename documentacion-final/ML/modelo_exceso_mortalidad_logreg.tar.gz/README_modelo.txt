
Modelo de Machine Learning - Regresion Logistica

Problema:
Clasificacion binaria de exceso de mortalidad.

Variable objetivo:
exceso_mortalidad

Definicion:
La variable objetivo toma valor 1 cuando las muertes observadas superan en al menos 15%
el promedio historico pre-COVID 2015-2019 para el mismo pais y mes. En caso contrario,
toma valor 0.

Modelo:
Regresion Logistica entrenada en Databricks usando scikit-learn.

Umbral de decision:
0.5

Metricas finales:
Accuracy: 0.8189415041782729
Precision: 0.5433070866141733
Recall: 0.9078947368421053
F1-score: 0.6798029556650246

Matriz de confusion:
[[225  58]
 [  7  69]]

Archivos incluidos:
- modelo_logreg.joblib
- metricas_modelo.json
- matriz_confusion.csv
- comparacion_umbrales.csv
- coeficientes_modelo.csv
- README_modelo.txt

Seguridad:
No se incluyen credenciales ni secrets dentro de este archivo.
La conexion al DW se realizo mediante dbutils.secrets.get().
